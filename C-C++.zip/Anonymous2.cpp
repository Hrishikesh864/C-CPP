#include<iostream>
using namespace std;

typedef class{
    int i;
    public:
    void setData(int i){
        this->i = i;
    }
    void print(){
        cout<<"Value of i:"<< this->i<<endl;
    }
}myClass;

class A : public myClass{
    public:
    A(){
        setData(20);
        print();
    }
};

int main(){
    myClass obj1, obj2;
    obj1.setData(10);
    obj1.print();
    obj2.setData(100);
    obj2.print();
    A a;
}