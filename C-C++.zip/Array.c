#include <stdio.h>
union unionJob
{
    char name[32];
    float salary;
    int workerNo;
}ujob;

struct structJob{
    char name[32];
    float salary;
    int workerNo;
}sjob;
int main(){
    printf("size of union =%ld bytes",sizeof(ujob));
    printf("size of structure =%ld bytes",sizeof(sjob));
}