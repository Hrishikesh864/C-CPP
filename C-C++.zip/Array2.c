#include<stdio.h>
void main(){
    int a[2];
    printf("%d ",a[3]);
    printf("%d ",a[-2]);
}