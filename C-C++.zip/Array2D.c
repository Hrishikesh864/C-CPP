#include <stdio.h>
void main(){
int i,j;
int x[3][2] = {{0,1},{2,3},{4,5}};
for(i=0;i<3;i++){
    for(j=0;j<2;j++){
        printf("%d   ",x[i][j]);
    }printf("\n");
}
}