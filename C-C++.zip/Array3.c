#include<stdio.h>
void main(){
    int a[5];
    printf("Size of One Integer = %d\n",sizeof(int));
    for(int i=0;i<5;i++){
            printf("Address of a[%d] is %p\n",i,&a[i]);
    }
}