#include <stdio.h>
void main(){
int i,j,k;
int x[3][2][2] = {{{0,1},{2,3}},{{4,5},{6,7}},{{8,9},{10,11}}};
for(i=0;i<3;i++){
    for(j=0;j<2;j++){
        for(k=0;k<2;k++){
        printf("%d   ",x[i][j][k]);
        }
    }printf("\n");
}
}