#include<iostream>
using namespace std;

class Car{

    public:
    virtual void Start()=0;
    virtual void Stop()=0;
    Car(){}

    virtual ~Car() = 0;
};
Car::~Car(){
    cout<<"I am Destructor of Car"<<endl;
}

class Innova: public Car{
    public:
    void Start(){
        cout<< "Innova Started"<<endl;
    }
    void Stop(){
        cout<< "Innova Stopped"<<endl;
    }
    Innova(){}
    ~Innova(){
        cout<< "Destructor of Innova"<<endl;
    }
};

class Swift: public Car{
    public:
    void Start(){
        cout<< "Swift Started"<<endl;
    }
    void Stop(){
        cout<< "Swift Stopped"<<endl;
    }
    Swift(){}
    ~Swift(){
        cout<< "Destructor of Swift"<<endl;
    }
};

int main(){
    Car *c = new Innova();
    c->Start();
    c->Stop();
    delete c;
    c=new Swift();
    c->Start();
    c->Stop();
    delete c;
}