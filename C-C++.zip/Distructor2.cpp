#include<iostream>
using namespace std;
class Base{
     public:
     Base(){
        cout<<"Constructor of Base"<<endl;
     }
     virtual void Display(){
        cout<<"Display of Base"<<endl;
    }
    ~Base(){
        cout<<"Destructor of Base"<<endl;
     }
};

class Derived:public Base{
    public:
     Derived(){
        cout<<"Constructor of Derived"<<endl;
     }
     virtual void Display(){
        cout<<"Display of Derived"<<endl;
    }
    ~Derived(){
        cout<<"Destructor of Derived"<<endl;
     }
};

class Derived2:public Derived{
    public:
     Derived2(){
        cout<<"Constructor of Derived2"<<endl;
     }
     virtual void Display(){
        cout<<"Display of Derived2"<<endl;
    }
    ~Derived2(){
        cout<<"Destructor of Derived2"<<endl;
     }
};

int main(){
    Derived2 p;
    p.Display();
}