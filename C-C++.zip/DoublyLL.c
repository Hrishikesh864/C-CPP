#include<stdio.h>
#include<stdlib.h>
struct node{
    int data;
    struct node *next;
    struct node *prev;
};
struct node *head = NULL;
struct node *last = NULL;
void insertLast(int data){
    struct node *node = (struct node*)malloc(sizeof(struct node));
    node->data = data;
    node->next = NULL;
    node->prev = NULL;
    if (head==NULL){
        head = node;
        last = node;
    }
    else{
        last->next=node;
        node->prev=last;
        last = node;
    }
}
void print(struct node* head){
    do{
        printf("%d<->",head->data);
        head=head->next;
    }
    while(head!=NULL);
}
void delete(int pos){
    struct node *node=head;
    for(int i=0;i<pos-1;i++){
        node=node->next;
    }
    node->prev->next=node->next;
    node->next->prev=node->prev;
    free(node);
}
void deleteData(int data1){
    struct node *node=head;
    int c=1;
    int f=0;
    while(node!=NULL){
        if(node->data==data1){
            f=1;
            delete(c);
            break;
        }
        c++;
        node=node->next;
    }
}
void main(){
    insertLast(4);
    insertLast(40);
    insertLast(400);
    insertLast(4000);
    insertLast(40000);
    print(head);
    delete(4);
    printf("\n");
    print(head);
    printf("\n");
    deleteData(40);
    print(head);
}