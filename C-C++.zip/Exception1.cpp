#include<iostream>
using namespace std;
int main(){
    int a= 1;
    float b=0;
   
    cout<<"Program Starts"<<endl;
    try{
        if(b==0){
            throw b;
        }
    }
    catch(float b){
        cout<<"Float"<<b<<endl;
    }
    catch(char b){
        cout<<"Float"<<b<<endl;
    }
    catch(...){
        cout<<"enter b again";
        cin>>b;
        float c=a/b;
        cout<<c;
        cout<<"Default Exception Catch"<<endl;
    }
    cout<<"Program Ends"; 
}