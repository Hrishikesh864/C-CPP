#include<iostream>
using namespace std;
int main(){
    int a = 0;
    float b;
    char c='a';
    double d =12;
    cout<<"Program Starts"<<endl;
    try{
        if(a==0){
            throw a;
        }
    }
    catch(float b){
        cout<<"Float"<<a<<endl;
    }
    catch(char c){
        cout<<"Char"<<c<<endl;
    }
    catch(...){
        cout<<"enter b again";
        cin>>d;
        float c=a/b;
        cout<<c;
        cout<<"Default Exception Catch"<<endl;
    }
    cout<<"Program Ends"; 
}