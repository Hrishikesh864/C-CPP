#include<iostream>
using namespace std;

void exceptionFunction(){
    try{
        throw 0;
    }
    catch(int i){
        cout<<"\n In function: wrong Input: "<<i;
        throw;
    }
}

int main(){
    int var = 0;
    cout<<"Simple C++ Program"<<endl;
    try{
        exceptionFunction();
    }
    catch(int ex){
        cout<<"\n In Main : Wrong Input"<< ex;
    }
    return 0;
}