#include<iostream>
using namespace std;

class E{
    public:
    const char* error;
    E(const char* arg) : error(arg){}
};

class A{
    public:
    ~A(){
        
    }
};

class B{
    public:
    ~B(){
        
    }
};

int main() try {
    cout<<"In Main"<< endl;
    static A cow;
    B bull;
}
catch (E& e){
    cout<< e.error<< endl;
}