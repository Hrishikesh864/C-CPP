#include<stdio.h>
int main(){
    FILE *fp;
    fp = fopen("/home/hrishikesh/Hrishikesh/Text.txt","w+");
    fprintf(fp, "This is for testing \n");
    fputs("This is testing fputs\n",fp);
    fclose(fp);
}