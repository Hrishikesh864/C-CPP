class A{
    public:
    int f(){}
};
