#include<iostream>
using namespace std;

int sum(int a, int b){
    return a+b;
}

double sum(double a, double b){
    return a+b;
}

template <class T> 
T s(T a, T b){
    return a+b;
}

template <class T, class U> 
bool are_equal(T a, U b){
    return (a==b);
}

int main(){
    cout<<sum(2,3)<<endl;
    cout<<sum(2.5,3.6)<<endl;
    cout<<s(2,3)<<endl;
    cout<<s(2.5,3.6)<<endl;
    if(are_equal(10,10.0))
    cout<<"x and y are equal"<<endl;
    else
    cout<<"x and y are not equal"<<endl;
    return 0;
}