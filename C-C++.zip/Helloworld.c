#include <stdio.h>

int fun(){
    static int count = 0;
    count++;
    return count;
}

void main(){
    int a = fun();
    printf("%d", a);
    int b = fun();
    printf("%d", b);
}