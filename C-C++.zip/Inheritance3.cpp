#include<iostream>
using namespace std;

class BaseClass{
    public:
    void print(){
        cout<<"Example of Multilevel Inheritance"<<endl;
    }
};

class DerivedClass: public BaseClass{};

class DerivedClass2: public DerivedClass{};

int main(){
    DerivedClass2 x;
    x.print();
}
