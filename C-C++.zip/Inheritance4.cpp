#include<iostream>
using namespace std;
class Single_base_class{
    public:
    int x,y;
    void data(){
        cout<<"\n Enter value of x and y ->"<<endl;
        cin>>x>>y;
    }
};

class Derived1:public Single_base_class{
    public:
    void product(){
        cout<<"\n The Product is "<<x*y<<endl;
    }
};

class Derived2:public Single_base_class{
    public:
    void sum(){
        cout<<"\n The Sum is "<<x+y<<endl;
    }
};

int main(){
    Derived1 obj1;
    Derived2 obj2;
    obj1.data();
    obj1.product();
    obj2.data();
    obj2.sum();
}
