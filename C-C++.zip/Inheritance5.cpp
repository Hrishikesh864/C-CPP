#include<iostream>
using namespace std;

class World{
    public:
    World(){
        cout<<"This is World\n";
    }
};

class Continent: public World{
    public:
    Continent(){
        cout<<"This is Continent\n";
    }
};

class Country: public Continent{
    public:
    Country(){
        cout<<"This is Country\n";
    }
};

class India: public Country{
    public:
    India(){
        cout<<"This is India\n";
    }
};

int main(){
    India Myworld;
}
