#include<iostream>
using namespace std;

class Base_Class{
   public:
    int x = 3;
};

class Class_1 : public Base_Class{
    public:
    int y = 4;
};

class Class_2 : public Base_Class{
    public:
    int z=5;
};

class Derived_Class : public Class_1 , public Class_2 {
    public:
    int i = Class_1::x;
    void sum(){
        cout<<"Sum of Numbers "<< i+y+z<< endl;
    }
};

int main(){
    Derived_Class obj;
    obj.sum();
}
