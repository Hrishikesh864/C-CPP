#include<stdio.h>
#include<stdlib.h>
struct node{
    int data;
    struct node *next;
};
struct node *head = NULL;
struct node *last = NULL;
void insertLast(int data){
    struct node *node = (struct node*)malloc(sizeof(struct node));
    node->data = data;
    node->next = NULL;
    if (head==NULL){
        head=node;
        last = node;
    }
    else{
        last->next=node;
        last = node;
    }
}
void print(struct node* head){
    do{
        printf("%d->",head->data);
        head=head->next;
    }
    while(head!=NULL);
}

void reverse(){
    struct node *prev = NULL;
    struct node *next1 = NULL;
    struct node *curr = head;
    while (curr!=NULL){
        next1 = curr->next;
        curr->next=prev;
        prev=curr;
        curr=next1;
    }
    head=prev;
}

void insertSort(int data){
    struct node *p;
    struct node *node = (struct node*)malloc(sizeof(struct node));
    node->data=data;
    if (head==NULL || data<head->data){
        node->next=head;
        head=node;
    }
    else{
        struct node *p = head;
        while(p->next!=NULL && p->next->data<=data){
            p=p->next;
        }
    node->next=p->next;
    p->next= node;
    }
}

void isLoop(){
    int f=0;
    struct node *p=head,*q=head;
    while (p!= NULL && p->next!=NULL && q!=NULL){
        p=p->next->next;
        q=q->next;
        if (p==q){
            printf("LOOP");
            f=1;
            break;
        }
    }
    if(f==0){
        printf("NO LOOP");
    }
}

void create(int A[],int n){
    struct node *t;
    head->data=A[0];
    head->next=NULL;
    last=head;
    for(int i=1;i<n;i++){
        t=(struct node*)malloc(sizeof(struct node));
        t->data=A[i];
        t->next=NULL;
        last=head;
    }
}
 
void main(){
    /*insertLast(4);
    insertLast(40);
    insertLast(400);
    print(head);
    //reverse();
    printf("\n");
    print(head);
    // insertSort(15);
    // insertSort(55);
    // insertSort(5);
    // insertSort(1);
    // printf("\n");
    // print(head);
    isLoop();
    last->next=head;
    printf("\n");
    isLoop();*/
    int A[]={3,5,7,8,11};
    create(A,5);
    print(head);
}