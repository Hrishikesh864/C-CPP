#include<iostream>
using namespace std;

void fun(){
    class Test{
        public:
        void method(){
            cout<<"Local Class Method() called";
        }
    };
    Test t;
    t.method();
}

int main(){
    fun();
}