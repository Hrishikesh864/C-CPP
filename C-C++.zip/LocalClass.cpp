int x;
void f(){
    static int y;
    int x;
    extern int g();
    class local{
        int h(){return y;}
        int g(){return x;}
        int k(){return ::x;}
        int l(){return g()}
    };
}

int main(){}