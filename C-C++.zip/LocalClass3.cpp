#include<iostream>
using namespace std;

void fun(){
    class Test{};
    Test t;
    Test *tp;
}

int main(){
    fun();
}