#include<iostream>
using namespace std;
int *p;
void fun(){
    static int y=10;
    p=&y;
    class Local{
        public:
        int fun();
        Local(){
            cout<<"I am Constructor";
            }
        int g(){return 0;}
        //static int a;
        int b;
    };
    Local k;
}

int main(){
    fun();
    cout << "\n" << *p;
}