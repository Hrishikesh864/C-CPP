#include<iostream>
using namespace std;

int main(){
    int i,j,n;
    cout<<"Enter the number of elements in two arrays"<<endl;
    cin>>n;
    int a[n],b[n],c[n][n];
    cout<<"Enter First Array"<<endl;
    for(i=0;i<n;i++){
        cin>>a[i];
    }
    cout<<"Enter Second Array"<<endl;
    for(j=0;j<n;j++){
        cin>>b[j];
    }

    cout<<"Multiplication Matrix is "<<endl;
    for(i=0;i<n;i++){
        for(j=0;j<n;j++){
            c[i][j]=a[i]*b[j];
            cout<<c[i][j]<<"  ";
        }cout<<endl;
    }

    cout<<"Addition Matrix is "<<endl;
    for(i=0;i<n;i++){
        for(j=0;j<n;j++){
            c[i][j]=a[i]+b[j];
            cout<<c[i][j]<<"  ";
        }cout<<endl;
    }

    cout<<"Substraction Matrix is "<<endl;
    for(i=0;i<n;i++){
        for(j=0;j<n;j++){
            c[i][j]=a[i]-b[j];
            cout<<c[i][j]<<"  ";
        }cout<<endl;
    }
}