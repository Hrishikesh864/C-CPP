#include<iostream>
using namespace std;

namespace first{
    double x=3;
    double y=2;
}

namespace second{
    double x=3.1414;
    double y=2.7183;
}

int main(){
    {
    using namespace first;
    cout<<x<<endl;
    }
    {
    using namespace second;
    cout<<x<<endl;
    }
    return 0;
}