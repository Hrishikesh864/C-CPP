#include<iostream>
using namespace std;

int x = 20;
namespace outer
{
int x = 10;		
namespace inner
{
	int z = x; // this x refers to outer::x
}
}

int main()
{
cout<<outer::inner::z; //prints 10

return 0;
}
