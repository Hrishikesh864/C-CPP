#include<iostream>
using namespace std;

namespace addition{
    int operation(){
        int x,y;
        cin >> x>>y;
        return x+y;}
}

namespace substraction{
    int operation(){
        int x,y;
        cin>>x>>y;
        return x-y;}
}

namespace multiplication{
    int operation(){
        int x,y;
        cin>>x>>y;
        return x*y;}
}

namespace division{
    int operation(){
        int x,y;
        cin>>x>>y;
        return x/y;}
}

int main(){
    cout<<"addition = "<<addition::operation()<<endl;
    cout<<"substraction = "<<substraction::operation()<<endl;
    cout<<"multiplication = "<<multiplication::operation()<<endl;
    cout<<"division = "<<division::operation()<<endl;
    return 0;
    }