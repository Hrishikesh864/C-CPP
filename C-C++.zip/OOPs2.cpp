#include<iostream>
using namespace std;

class Rectangle{
    int height;
    int width;
    public:
    int area(int a,int b){return a*b;}
    Rectangle(int a, int b){
        height = a;
        width = b;
    }
};

int main(){
    Rectangle(4,5);
    cout<<Rectangle(4,5).area(4,5)<<endl;
}