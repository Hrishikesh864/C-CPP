#include<iostream>
using namespace std;
class Fred{
    public:
    Fred(){

    }
};
int main(){
    Fred b;
    Fred a[10];
    Fred*p = new Fred[10];
}