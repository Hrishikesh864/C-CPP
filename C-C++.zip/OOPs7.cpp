#include<iostream>
using namespace std;
class Line{
    public:
    int size;
    Line(){
        size=30;
    }
};

int main(){
    const Line l;
    l.size = 40;
    cout<<"Line size is"<<" "<<l.size<<" "<<"cm";
    Line l1;
    cout<<"Line size is"<<" "<<l1.size<<" "<<"cm";
    return 0;
}