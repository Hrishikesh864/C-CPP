#include<iostream>
using namespace std;

class Complex {
public:
	double real, imag;
	Complex(double r = 0., double i = 0.);
	
	Complex operator + (const Complex&) const;
};
Complex::Complex(double r, double i){
    real = r;
    imag = i;
}
Complex Complex :: operator+(const Complex& c) const
	{	Complex result;
		result.real = this->real + c.real;
		result.imag = this->imag + c.imag;
		return result;
	}

int main()
{
	Complex x(4,4);
    Complex y(6,20);
    Complex z = x + y;
	cout<<z.imag<<endl;
    cout<<z.real<<endl;
    return 0;
}

