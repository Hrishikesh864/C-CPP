#include<iostream>
using namespace std;

class OverLoad{
    private:
    int a;
    int b;
    int c = 0;
    public:
    OverLoad() : a(0), b(0){}

    void in(){
        cout<<"Enter the first number : ";
        cin>>a;
        cout<<"Enter the second number : ";
        cin>>b;
    }

    void operator--(){
        a = --a;
        b = --b;
    }

    void out(){
        cout << "The Decremental Elements of Object are "<< a <<" and "<< b<< endl;
    }

    OverLoad OverLoad :: operator*(const OverLoad& c) const
	{	OverLoad result;
		result.a = this->a + c.a;
		result.b = this->b + c.b;
		return result;
	}
};

int main(){
    OverLoad obj;
    obj.in();
    --obj;
    obj.out();
    OverLoad obj1;
    obj1*obj;
    return 0;
}