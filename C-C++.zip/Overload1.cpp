#include<iostream>
using namespace std;

void display(int a){
    cout<<"a="<<a<<endl;
}

void display(int a, int b){
    cout<<"a="<<a<<"and b="<<b<<endl;
}

int main(){
    display(5);
    display(5,50);
}