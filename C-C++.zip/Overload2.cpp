#include<iostream>
using namespace std;

int function(float){
    cout<<"Data Type: float\n";
    return 0;
}

void function(int){
    cout<<"Data Type: int\n";
}

void function(double){
    cout<<"Data Type: double\n";
}

int main(){
    function(1.0f);
    function(1);
    function(1.0);
    function(1);
}