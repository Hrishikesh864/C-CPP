#include<iostream>
using namespace std;

int multiply(float a, float b){
    cout<<a*b<<endl;
    return 0;
}

int multiply(int a, int b){
    cout<<a*b<<endl;
    return a*b;
}

double multiply(double a, double b){
    cout<<a*b<<endl;
}

void multiply(double a, int b){
    cout<<a*b<<endl;
}


int main(){
    multiply(2,3);
    multiply(2.0f,3.0f);
    return 0;
}