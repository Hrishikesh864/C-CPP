#include<iostream>
using namespace std;

int add(int a){
    int b=10;
    return a+b;
}

int add(int a, int b = 100){
    return a+b;
}

int main(){
    int a = 100,b;
    cout<<add(a,b);
}