#include<stdio.h>
int main(){
int x;
print("%p",&x);
}