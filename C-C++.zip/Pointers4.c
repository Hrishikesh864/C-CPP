#include<stdio.h>
#include<stdlib.h>
int main(){
    int *ptr = (int *)malloc(sizeof(int));
    *ptr = 50;
    free(ptr);
    ptr = NULL;
    return 0;
}