#include<stdio.h>
int main(){
    int a=10;
    int b=20;
    int *p1=&a;
    int *p2=&b;
    printf("Before Swap: *p1=%d *p2=%d",*p1,*p2);
    *p1 = *p1 + *p2;
    *p2 = *p1 - *p2;
    *p1 = *p1 - *p2;
    printf("\n  After Swap: *p1=%d *p2=%d",*p1,*p2);
    return 0;
}