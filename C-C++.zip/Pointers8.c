#include<stdio.h>
int addition(){
    int a,b;
    printf("Enter Two numbers?");
    scanf("%d %d",&a,&b);
    return (a+b);
}
int substraction(){
    int a,b;
    printf("Enter Two numbers?");
    scanf("%d %d",&a,&b);
    return (a-b);
}

int square(int a){
    return a*a;
}
int main(){
    int result;
    int (*ptr)();
    ptr = &addition;
    result = (*ptr)();
    printf("The sum is %d",result);
    ptr = &substraction;
    result = (*ptr)();
    printf("The difference is %d",result);
    ptr = &square;
    result = (*ptr)(4);
    printf("The square is %d",result);
    
}
