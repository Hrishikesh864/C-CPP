#include<stdio.h>
#include<stdlib.h>
struct node{
    int info;
    struct node *link;
    };
struct node *front=NULL;
struct node *rear = NULL;

// void initializeQueue(){
//     front=NULL;
//     rear=NULL;
// }


void insert(int x){
    struct node *temp;
    temp = (struct node*)malloc(sizeof(struct node));
    if(temp==NULL){
        printf("Memory not Available");
        return;
    }
    temp->info=x;
    temp->link=NULL;
    if(front==NULL){
        front = temp;
    }
    else{
        rear->link=temp;
    }
    rear=temp;
}

void delete(){
    struct node *temp= front;
    front = front->link;
    free(temp);
}

int isEmpty(){
    if(front==NULL){
        printf("Empty");
        return 1;
    }
    else{
        printf("Not Empty");
        return 0;
    }
}

void peek(){
    if(front==NULL){
        printf("Empty");
    
    }
    printf("%d",front->info);
}

void print(){
    struct node *temp= front;
    while(temp!=NULL){
        if(temp->link==NULL){
            printf("%d",temp->info);
        }
        else{
            printf("%d-",temp->info);
        }
        temp=temp->link;
    }
}

void main(){
    isEmpty();
    printf("\n");
    insert(9);
    insert(11);
    insert(61);
    insert(18);
    insert(99);
    print();
    printf("\n");
    peek();
    delete();
    printf("\n");
    print();
    printf("\n");
    peek();
    
    printf("\n");
    isEmpty();
    }
