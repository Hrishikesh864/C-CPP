#include<iostream>
using namespace std;

struct mystruct{
    int x;
    int y;
    char c;
    bool b;
};

int main(){
    struct mystruct f;
    f.x = 10;
    f.y = 20;
    f.c = 'A';
    f.b = true;

    int *p = reinterpret_cast<int*>(&f);
    cout<<sizeof(f)<<endl;
    cout<<*p<<endl;
    *p++;
    cout<<*p<<endl;
}