#include<iostream>
#include<set>

using namespace std;

int main(){
    set<int> s = {10,12,15,6};
    set<int> :: iterator it;
    cout<<"First element is:"<<*(s.begin());
    cout<<"\nLast element is:"<<*--(s.end())<<endl;
    
    //Tranversal()
    for(auto it = s.begin(); it!=s.end(); it++){
        cout<<" "<<*it;
    }cout<<endl;

    if(s.empty())
    cout<<"Empty";
    else
    cout<<"Not Empty";

    cout<<"\nSize of the Set: "<<s.size();
    cout<<"\nMax Size: "<<s.max_size();

    s.erase(s.begin());
    s.erase(12);
    cout<<"\nAfter Removig First and the element 12";
    for(auto it=s.begin();it!=s.end();it++){
        cout<<" "<<*it;
    }
    s.insert(5);
    cout<<"\nAfter Inserting the New Element 5: ";
    for(auto it = s.begin(); it!=s.end(); it++){
        cout<<" "<<*it;
    }cout<<endl;

    if(s.count(15)==1){
        cout<<endl<<"15 is present in the set";}
    else{
        cout<<endl<<"15 is not Present";
    }

    s.clear();
    if(s.empty())
    cout<<"\nNow, the set is empty";
    else
    cout<<"\nSet is not Empty";
    return 0;

    }
