#include<iostream>
using namespace std;
typedef unsigned char BYTE;
void f(){
    char ch;
    int i = 65;
    float f =25;
    double dbl;

    ch = static_cast<char>(i);
    dbl = static_cast<double>(f);
    i = static_cast<BYTE>(ch);
}

int main(){
    f();
}