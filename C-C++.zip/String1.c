#include<stdio.h>
#include<string.h>
int main(){
    char ch[11]= {'a','a','b','c','g','y','y','z','z','z','z'};
        char ch2[11]="abgdrxzrduy";
        printf("Char Array Value is: %s\n", ch);
        printf("String Literal Value is: %s\n", ch2);
        return 0;
}