#include<stdio.h>
#include<string.h>
int main(){
    char name[20];
    printf("Enter Name:");
    scanf("%s",name);
    printf("Your Name is %s.",name);
    return 0;
}
