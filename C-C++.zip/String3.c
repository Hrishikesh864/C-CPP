#include<stdio.h>
#include<string.h>
int main(){
    char name[30];
    printf("Enter Name: ");
    fgets(name, sizeof(name), stdin);
    printf("Name:%s",name);
    return 0;
}