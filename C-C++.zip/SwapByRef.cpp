#include<iostream>
using namespace std;

void swap(int &m,int &n){
    int temp;
    temp = m;
    m = n;
    n = temp;
}

int main(){
    int a=1;
    int b=2;
    cout<<"Before Swapping"<<endl;
    cout<<"a = "<< a << endl;
    cout<<"b = "<< b << endl;

    swap(a,b);

    cout<<"After Swapping"<<endl;
    cout<<"a = "<< a << endl;
    cout<<"b = "<< b << endl;

    return 0;
}