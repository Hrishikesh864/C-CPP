#include<iostream>
using namespace std;

int main(){
    int i = 9;
    double n =i;

    cout<<"i = "<<i<<endl;
    cout<<"n = "<<n<<endl;

    float j = 9.5;
    int m =j;

    cout<<"j = "<<j<<endl;
    cout<<"m = "<<m<<endl;
}