#include<iostream>
#include<vector>

using namespace std;

int main(){
    vector<int> a;

    for (int i = 1; i<=5; i++){
        a.push_back(i);
    }
    cout<<"Size : " << a.size();
    cout<<"\nCapacity : "<< a.capacity();
    cout<<"\nMax_Size : "<< a.max_size();
    a.resize(4);
    cout<<"\nSize : " << a.size();
    cout<<"\nCapacity : "<< a.capacity();
    if(a.empty() == false)
        cout<< "\nVector is not Empty";
    else
        cout<< "\nVector is Empty";
    return 0;
}