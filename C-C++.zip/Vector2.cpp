#include<iostream>
#include<vector>
using namespace std;

int main(){
    vector<int> a;
    for(int i=1; i<= 10; i++){
        a.push_back(i*10);
    }
    cout<<"\nReference Operator [g] : a[2] = "<<a[2];
    cout<<"\nat : a.at(4) = " << a.at(4);
    cout<<"\nFront() : a.front() = " << a.front();
    cout<<"\nBack() : a.back() = " << a.back();
    int* pos = a.data();
    cout << "\nThe First Element is "<< *pos;
    return 0;
}