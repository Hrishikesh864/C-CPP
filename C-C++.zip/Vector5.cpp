#include<iostream>
#include<vector>
using namespace std;

int main(){
    vector<int> num{1,2,3,4,5};

    vector<int>::iterator iter;
    iter = num.begin();
    cout<<*iter<<endl;
    return 0;
}