#include<iostream>
using namespace std;

int main(){
    int a=10,b=5;
    if(a+b>10){
        cout << "Yes  "<<a+b<<" is greater than 10";
    }
    return 0;
}