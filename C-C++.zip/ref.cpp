#include<iostream>
using namespace std;
int main(){
    int i=2;
    double d=2.2;
    int &r=i;
    double &s=d;
    cout << i <<endl;
    cout << "Reference = "<< r << endl;
    cout << d <<endl;
    cout << "Reference = "<< s << endl;
    return 0;
}