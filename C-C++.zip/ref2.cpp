#include<iostream>
using namespace std;

bool Vote(int x){
    if(x<18){
    cout<<"Not Allowed"<<endl;
    return false;}
    else{
    cout<<"Allowed"<<endl;
    return true;}
}


int main(){
    int age;
    cout<<"Enter Age"<<endl;
    cin>>age;
    Vote(age);
    cout<<"Call By Value "<<age<<endl;
    return 0;
}