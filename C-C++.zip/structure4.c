#include<stdio.h>

struct Point{
    int x,y,z;
};

int main(){
    
}