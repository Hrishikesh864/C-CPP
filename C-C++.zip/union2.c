#include <stdio.h>
union unionJob
{
    char name[32];
float salary;
    int workerNo;
}j;

int main(){
    j.salary = 12.3;
    printf("Salary = %.1f\n",j.salary);
    j.workerNo = 100;
    printf("Salary = %.1f\n",j.salary);
    printf("Number of Workers = %d",j.workerNo);
    return 0;
}