#include<iostream>
using namespace std;
class Base{
     public:
     virtual void Display(){
        cout<<"Display of Base"<<endl;
    }
};

class Derived:public Base{
    public:
    // virtual void Display(){
      //  cout<<"Display of Derived"<<endl;
    //}
};

class Derived2:public Base{
    public:
    virtual void Display(){
        cout<<"Display of Derived2"<<endl;
    }
};



int main(){
  Base *p = new Derived();
    p->Display();
}

